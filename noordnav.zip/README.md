It was a great experience, and although I faced some challenges, I’m happy that I overcame them. I know I will improve as I continue to put in more effort and practice.
